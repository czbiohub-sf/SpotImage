from setuptools import setup, find_packages

setup(
	name='spotimage',
	version='0.1',
	packages=find_packages(),
	license='MIT',
	long_description=open('README.md').read(),
	author='jenny.vophamhi'
)