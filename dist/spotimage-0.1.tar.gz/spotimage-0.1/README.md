# SpotImage

The SpotImage tool generates synthetic FISH spot images. 